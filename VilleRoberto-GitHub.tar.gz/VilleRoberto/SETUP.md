# 🚀 Quick Setup Guide for Rahapuu

Welcome to the **VilleRoberto** repository containing the Rahapuu children's savings game! This guide will get you up and running in under 5 minutes.

## 🎯 What You'll Get

A complete, production-ready children's savings game with:
- 🌳 Interactive money tree that grows with savings
- 🎯 Savings goals with progress tracking
- 💰 Easy savings entry interface
- 🎨 Beautiful child-friendly animations
- 📱 Mobile-optimized design
- 🌍 Finnish and English language support

## ⚡ Quick Start (3 Steps)

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```

### 3. Open in Browser
Navigate to `http://localhost:5173`

**That's it! The app is running! 🎉**

## 🌐 Deploy Online (Choose One)

### Option A: Netlify (Easiest)
1. Build the app: `npm run build`
2. Go to [netlify.com](https://netlify.com)
3. Drag and drop the `dist/` folder
4. **Your app is live!**

### Option B: Vercel
1. Build the app: `npm run build`
2. Go to [vercel.com](https://vercel.com)
3. Upload the `dist/` folder
4. **Your app is live!**

### Option C: GitHub Pages
1. Push this repository to GitHub
2. Go to Settings → Pages
3. Select source branch
4. **Your app is live!**

## 📋 Available Commands

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint

# Testing the app
npm run dev          # Start and test all features
npm run build        # Ensure production build works
```

## 🎮 How to Test

1. **Start the app** (`npm run dev`)
2. **Add a savings goal**: Go to Goals → Add Goal
3. **Add some savings**: Go to Savings → Add Savings
4. **Watch the tree grow**: Go to Tree → See your money tree!

## 🔧 Customization

### Change Currency
Edit `src/utils/calculations.ts` to change from € to your currency.

### Add Languages
Edit `src/context/AppContext.tsx` to add new language support.

### Modify Tree Elements
Edit `src/components/Tree.tsx` to change how the tree looks.

### Adjust Colors
Edit `tailwind.config.js` to customize the color scheme.

## 🛡️ Important Notes

- **No Backend Required**: Everything runs in the browser
- **Privacy Safe**: All data stored locally only
- **Mobile-First**: Designed for tablets and phones
- **Offline Capable**: Works without internet

## 📱 Perfect For

- **Children aged 4-12** learning about saving money
- **Parents** teaching financial literacy
- **Tablets** and mobile devices (primary use case)
- **Families** wanting private, safe savings tracking

## 🎯 Next Steps

1. **Test the app** with the steps above
2. **Deploy online** using one of the deployment options
3. **Use with children** to teach saving habits
4. **Customize** colors, currency, or language if needed

## 🆘 Need Help?

- **Documentation**: See `README.md` for full details
- **Deployment**: See `deploy.md` for detailed deployment guide
- **Issues**: Check browser console for errors
- **Support**: Create an issue on GitHub

## 🎉 Success!

If you can see the money tree and add savings, you're ready to go! The app is designed to be intuitive for children while providing meaningful financial education.

**Happy saving! 🌳💰**

---

*This setup guide gets you started quickly. For full documentation, see README.md*