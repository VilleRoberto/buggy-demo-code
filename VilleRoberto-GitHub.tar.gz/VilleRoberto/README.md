# 🌳 Rahapuu - Children's Savings Game

A delightful and interactive savings app designed to teach children about money management through a beautiful visual tree that grows as they save. Perfect for ages 4-12!

![Rahapuu Logo](https://via.placeholder.com/400x200/22c55e/ffffff?text=🌳+Rahapuu)

## 🎯 What is Rahapuu?

**Rahapuu** (Finnish for "Money Tree") is a gamified savings application that teaches children financial literacy through an interactive visual tree that grows as they save money. The app transforms abstract saving concepts into engaging, visual experiences that children can understand and enjoy.

## ✨ Key Features

### 🌱 Interactive Money Tree
- **Visual Growth**: Tree grows and changes as savings increase
- **Dynamic Elements**: 
  - 🍃 Leaves for small savings (< €2)
  - 🌸 Flowers for medium savings (€2-5)  
  - 🍎 Fruits for larger savings (€5+)
- **Beautiful Animations**: Smooth CSS animations when adding elements
- **Smart Positioning**: Algorithm prevents overlapping elements
- **Interactive Elements**: Clickable tree elements with details

### 🎯 Savings Goals Management
- **Custom Goals**: User-defined goals with names, amounts, icons, and colors
- **Visual Progress**: Animated progress bars showing completion percentage
- **Goal Linking**: Link specific savings to individual goals
- **Achievement Tracking**: Mark goals as completed when reached
- **Flexible Editing**: Modify goals before completion

### 💰 Savings Tracking
- **Easy Entry**: Simple interface for adding savings amounts
- **Quick Amounts**: Preset buttons for common values (€1, €2, €5, €10)
- **Transaction History**: Complete list of all savings with dates
- **Goal Association**: Optional linking of savings to specific goals
- **Smart Descriptions**: Auto-generated or custom descriptions

### 🎨 Beautiful UI/UX
- **Child-Friendly Design**: Large buttons, bright colors, friendly interface
- **Mobile-First**: Optimized for tablets and phones
- **Smooth Animations**: Engaging visual feedback
- **Responsive Layout**: Works on all screen sizes
- **Accessibility**: High contrast, readable text, touch-friendly

### 🌍 Bilingual Support
- **Finnish (Default)**: Complete Finnish language support
- **English**: Full English translation available
- **Dynamic Switching**: Language preference saved locally

## 🛠️ Technology Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom design system
- **Build Tool**: Vite for fast development and optimized builds
- **Icons**: Lucide React for beautiful, consistent icons
- **State Management**: React Context API with useReducer
- **Data Persistence**: Browser localStorage (no backend required)

## 🚀 Quick Start

### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn

### Installation & Development

1. **Clone or download this repository**
2. **Install dependencies:**
   ```bash
   npm install
   ```
3. **Start the development server:**
   ```bash
   npm run dev
   ```
4. **Open your browser** and navigate to `http://localhost:5173`

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## 🌐 Deploy Online

The app is built and ready to deploy! Since it's a client-side React app with no backend requirements, you can easily deploy it to various free hosting platforms.

### Option 1: Netlify (Recommended - Easiest)

1. **Go to [Netlify](https://netlify.com)** and create a free account
2. **Drag and drop** the entire `dist/` folder onto the Netlify dashboard
3. **Your app is live!** You'll get a URL like `https://magical-tree-12345.netlify.app`
4. **Optional**: Customize the domain name in site settings

### Option 2: Vercel
1. **Go to [Vercel](https://vercel.com)** and create a free account
2. **Click "New Project"**
3. **Upload the `dist/` folder** or connect your GitHub repository
4. **Deploy** - You'll get a URL like `https://rahapuu-abc123.vercel.app`

### Option 3: GitHub Pages
1. **Create a new repository** on GitHub
2. **Upload the contents** of the `dist/` folder to the repository
3. **Go to Settings** → Pages
4. **Select source** as "Deploy from a branch" and choose "main"
5. **Your app will be live** at `https://yourusername.github.io/repository-name`

**📄 For detailed deployment instructions, see [deploy.md](deploy.md)**

## 🎮 How to Use

### For Children

1. **Start with the Tree View**: This is your magical money tree! It starts small but will grow as you save.

2. **Add Your First Savings**: 
   - Tap the "Savings" tab
   - Tap the "+" button
   - Enter how much you saved
   - Watch your tree grow!

3. **Set Savings Goals**:
   - Tap the "Goals" tab
   - Tap "+" to add a new goal
   - Choose a name, amount, icon, and color
   - Save money toward your goal!

4. **Watch Your Progress**:
   - See your tree get bigger and more beautiful
   - Watch your progress bars fill up
   - Celebrate when you reach your goals!

### For Parents

This app is designed to be used together with your child. Here's how to make the most of it:

1. **Set Up Together**: Help your child create their first savings goal - something small and achievable.

2. **Regular Updates**: When your child saves money (allowance, gifts, found coins), update the app together.

3. **Discuss Progress**: Talk about how they're doing toward their goals and what they've learned.

4. **Celebrate Success**: When they reach a goal, celebrate together! Consider a small reward or special activity.

## 🏗️ Project Structure

```
VilleRoberto/
├── src/
│   ├── components/           # React components
│   │   ├── Tree.tsx         # Interactive money tree visualization
│   │   ├── Goals.tsx        # Savings goals management
│   │   ├── Savings.tsx      # Add and track savings
│   │   └── Navigation.tsx   # Mobile-friendly navigation
│   ├── context/
│   │   └── AppContext.tsx   # Global state management
│   ├── types/
│   │   └── index.ts         # TypeScript interfaces
│   ├── utils/
│   │   ├── storage.ts       # Local storage utilities
│   │   └── calculations.ts  # Business logic and calculations
│   ├── App.tsx              # Main application component
│   └── index.css            # Tailwind CSS + custom styles
├── public/                  # Static assets
├── dist/                    # Built files (ready for deployment)
├── tailwind.config.js       # Tailwind configuration
├── vite.config.ts          # Vite build configuration
├── deploy.md               # Detailed deployment guide
└── README.md               # This file
```

## 🛡️ Privacy & Data

- **Local Storage Only**: No external servers or data collection
- **Privacy Safe**: No personal information transmitted
- **Parent Controlled**: All features accessible to supervising adults
- **Offline Capable**: Works without internet connection

## 🎉 Educational Value

The app successfully addresses key financial literacy concepts:

- **Delayed Gratification**: Saving toward long-term goals
- **Visual Progress**: Concrete representation of abstract savings
- **Goal Setting**: Breaking large objectives into smaller steps
- **Positive Reinforcement**: Celebrating financial milestones
- **Habit Formation**: Regular saving behavior

## 🔮 Future Enhancements

### Phase 2 Features (Planned):
- **Chores System**: Earn money by completing tasks
- **Parent Dashboard**: Advanced oversight and controls
- **Sound Effects**: Audio feedback for achievements
- **Multiple Themes**: Different tree types and backgrounds
- **Achievement Badges**: Milestone rewards system

### Phase 3 Features (Future):
- **Family Sharing**: Multiple children per family
- **Cloud Sync**: Share progress across devices
- **Educational Content**: Mini-lessons about money
- **Spending Tracker**: Learn about wise spending
- **Bank Integration**: Connect to real savings accounts

## 🤝 Contributing

We welcome contributions! Please feel free to:

1. **Report bugs** or suggest features
2. **Submit pull requests** with improvements
3. **Share feedback** from children and parents
4. **Translate** to additional languages

## 📄 License

This project is open source and available under the MIT License.

## 🎯 Support

For questions, support, or feedback:
- **Issues**: Use GitHub Issues for bug reports
- **Discussions**: Use GitHub Discussions for questions
- **Email**: Contact the maintainers for direct support

## 🏆 Success Story

*"My 6-year-old daughter loves watching her money tree grow! She's been saving her allowance for weeks to buy a new toy, and now she understands why saving is important. The visual tree makes it so much more engaging than just numbers in a piggy bank!"* - Parent feedback

---

**Ready to help children learn about money in a fun, engaging way? Get started today! 🌳💰**

![Tree Growth](https://via.placeholder.com/600x200/22c55e/ffffff?text=🍃+→+🌸+→+🍎+Tree+Growth+Animation)
